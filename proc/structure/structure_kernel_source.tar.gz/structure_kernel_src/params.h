void GetParams(int strat, int argc, char *argv[]);
int  ReadString(char Word[],int maxlength,FILE *THEFILE);
int  ReadSpaceString(char Word[],int maxlength,FILE *THEFILE);
void PrintAllParams(FILE *file);
int Whitespace(char next);
